package ir.resume.maker

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class SectionType(val label: String) {
    INFO("اطلاعات (عنوان و مقدار)"),
    ENTRIES("سوابق (سمت، محل، تاریخ، توضیح)"),
    RATINGS("مهارت با امتیاز ستاره‌ای (ستون کناری)")
}

data class Item(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val subtitle: String = "",
    val date: String = "",
    val desc: String = "",
    val rating: Int = 4
)

data class Section(
    val id: String = UUID.randomUUID().toString(),
    val type: SectionType,
    val title: String,
    val items: List<Item> = emptyList()
)

data class Resume(
    val name: String = "",
    val photoPath: String = "",
    val phone: String = "",
    val address: String = "",
    val persianDigits: Boolean = true,
    val headerInfo: List<Item> = emptyList(),
    val sections: List<Section> = emptyList()
)

fun <T> List<T>.moved(i: Int, d: Int): List<T> {
    val j = i + d
    if (i !in indices || j !in indices) return this
    val m = toMutableList()
    val x = m.removeAt(i)
    m.add(j, x)
    return m
}

fun toFa(s: String): String = buildString {
    for (c in s) append(if (c in '0'..'9') ('۰' + (c - '0')) else c)
}

fun sampleResume(): Resume = Resume(
    name = "نام و نام خانوادگی",
    phone = "09120000000",
    address = "شهر - خیابان - کوچه - پلاک - کدپستی",
    headerInfo = listOf(
        Item(title = "تاریخ تولد", subtitle = "1370"),
        Item(title = "وضعیت تأهل", subtitle = "مجرد"),
        Item(title = "وضعیت سربازی", subtitle = "پایان خدمت")
    ),
    sections = listOf(
        Section(
            type = SectionType.INFO, title = "درباره من",
            items = listOf(
                Item(title = "کد ملی", subtitle = "0000000000"),
                Item(title = "تلفن ثابت", subtitle = "021-00000000")
            )
        ),
        Section(
            type = SectionType.ENTRIES, title = "سوابق شغلی",
            items = listOf(
                Item(
                    title = "سرپرست کارگاه", subtitle = "نام شرکت",
                    date = "1395/01/01 - 1399/01/01", desc = "توضیح کوتاه درباره پروژه یا مسئولیت"
                )
            )
        ),
        Section(
            type = SectionType.ENTRIES, title = "سوابق تحصیلی",
            items = listOf(
                Item(title = "کارشناسی مهندسی", subtitle = "نام دانشگاه", date = "1390")
            )
        ),
        Section(
            type = SectionType.RATINGS, title = "مهارت‌ها",
            items = listOf(
                Item(title = "نرم‌افزار اکسل", rating = 5),
                Item(title = "مدیریت پروژه", rating = 4)
            )
        ),
        Section(
            type = SectionType.RATINGS, title = "زبان",
            items = listOf(
                Item(title = "فارسی", rating = 5),
                Item(title = "انگلیسی", rating = 3)
            )
        )
    )
)

private fun Item.toJson() = JSONObject()
    .put("id", id).put("title", title).put("subtitle", subtitle)
    .put("date", date).put("desc", desc).put("rating", rating)

private fun itemFromJson(o: JSONObject) = Item(
    id = o.optString("id", UUID.randomUUID().toString()),
    title = o.optString("title"), subtitle = o.optString("subtitle"),
    date = o.optString("date"), desc = o.optString("desc"),
    rating = o.optInt("rating", 4)
)

private fun itemsFromJson(a: JSONArray?): List<Item> {
    if (a == null) return emptyList()
    return (0 until a.length()).map { itemFromJson(a.getJSONObject(it)) }
}

fun resumeToJson(r: Resume): JSONObject = JSONObject()
    .put("name", r.name).put("photoPath", r.photoPath)
    .put("phone", r.phone).put("address", r.address)
    .put("persianDigits", r.persianDigits)
    .put("headerInfo", JSONArray(r.headerInfo.map { it.toJson() }))
    .put("sections", JSONArray(r.sections.map { s ->
        JSONObject().put("id", s.id).put("type", s.type.name).put("title", s.title)
            .put("items", JSONArray(s.items.map { it.toJson() }))
    }))

fun resumeFromJson(o: JSONObject): Resume {
    val secs = o.optJSONArray("sections")
    val sections = if (secs == null) emptyList() else (0 until secs.length()).map {
        val s = secs.getJSONObject(it)
        Section(
            id = s.optString("id", UUID.randomUUID().toString()),
            type = try { SectionType.valueOf(s.optString("type")) } catch (e: Exception) { SectionType.ENTRIES },
            title = s.optString("title"),
            items = itemsFromJson(s.optJSONArray("items"))
        )
    }
    return Resume(
        name = o.optString("name"), photoPath = o.optString("photoPath"),
        phone = o.optString("phone"), address = o.optString("address"),
        persianDigits = o.optBoolean("persianDigits", true),
        headerInfo = itemsFromJson(o.optJSONArray("headerInfo")),
        sections = sections
    )
}
