package ir.resume.maker

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

object Storage {
    private fun file(ctx: Context) = File(ctx.filesDir, "resume.json")

    fun load(ctx: Context): Resume {
        return try {
            val f = file(ctx)
            if (f.exists()) resumeFromJson(JSONObject(f.readText())) else sampleResume()
        } catch (e: Exception) {
            sampleResume()
        }
    }

    fun save(ctx: Context, r: Resume) {
        try {
            file(ctx).writeText(resumeToJson(r).toString())
        } catch (_: Exception) {
        }
    }

    /** Saves the picked photo, cropped to 4:5 and scaled to 600x750. Returns the new path or null. */
    fun savePhoto(ctx: Context, uri: Uri, oldPath: String): String? {
        try {
            val resolver = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null

            val orientation = try {
                resolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees != 0f) {
                val m = Matrix().apply { postRotate(degrees) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            val ratio = 4f / 5f
            val w = bmp.width
            val h = bmp.height
            val cw: Int
            val ch: Int
            if (w.toFloat() / h > ratio) {
                ch = h
                cw = (h * ratio).toInt()
            } else {
                cw = w
                ch = (w / ratio).toInt()
            }
            val cropped = Bitmap.createBitmap(bmp, (w - cw) / 2, (h - ch) / 2, cw, ch)
            val scaled = Bitmap.createScaledBitmap(cropped, 600, 750, true)

            val out = File(ctx.filesDir, "photo_${System.currentTimeMillis()}.jpg")
            FileOutputStream(out).use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            if (oldPath.isNotBlank()) File(oldPath).delete()
            return out.absolutePath
        } catch (e: Exception) {
            return null
        }
    }
}
