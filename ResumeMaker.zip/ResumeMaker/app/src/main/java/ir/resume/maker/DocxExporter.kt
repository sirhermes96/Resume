package ir.resume.maker

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Builds a .docx (RTL, two-column layout matching the PDF design) without any external library. */
object DocxExporter {
    private const val SIDE_W = 3900
    private const val MAIN_W = 8006
    private const val BLUE = "3346D3"
    private const val SECTION = "2B3FC4"
    private const val NAVY = "1B2559"
    private const val FONT = "Tahoma"

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun run(text: String, sz: Int = 22, bold: Boolean = false, color: String = "1A1A1A"): String =
        "<w:r><w:rPr><w:rFonts w:ascii=\"$FONT\" w:hAnsi=\"$FONT\" w:cs=\"$FONT\"/>" +
            (if (bold) "<w:b/><w:bCs/>" else "") +
            "<w:color w:val=\"$color\"/><w:sz w:val=\"$sz\"/><w:szCs w:val=\"$sz\"/><w:rtl/></w:rPr>" +
            "<w:t xml:space=\"preserve\">${esc(text)}</w:t></w:r>"

    private fun para(
        runs: String,
        shade: String? = null,
        before: Int = 0,
        after: Int = 0,
        keepNext: Boolean = false,
        center: Boolean = false,
        exactLine: Int = 0
    ): String {
        val sb = StringBuilder("<w:p><w:pPr>")
        if (keepNext) sb.append("<w:keepNext/>")
        if (shade != null) sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$shade\"/>")
        sb.append("<w:bidi/><w:spacing w:before=\"$before\" w:after=\"$after\"")
        if (exactLine > 0) sb.append(" w:line=\"$exactLine\" w:lineRule=\"exact\"")
        sb.append("/>")
        if (center) sb.append("<w:jc w:val=\"center\"/>")
        sb.append("</w:pPr>").append(runs).append("</w:p>")
        return sb.toString()
    }

    private fun cell(width: Int, fill: String?, marLR: Int, content: String): String {
        val body = if (content.isEmpty()) "<w:p/>" else content
        return "<w:tc><w:tcPr><w:tcW w:w=\"$width\" w:type=\"dxa\"/>" +
            (if (fill != null) "<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$fill\"/>" else "") +
            "<w:tcMar><w:top w:w=\"0\" w:type=\"dxa\"/><w:left w:w=\"$marLR\" w:type=\"dxa\"/>" +
            "<w:bottom w:w=\"200\" w:type=\"dxa\"/><w:right w:w=\"$marLR\" w:type=\"dxa\"/></w:tcMar>" +
            "</w:tcPr>$body</w:tc>"
    }

    fun export(r: Resume, out: File) {
        fun t(s: String) = if (r.persianDigits) toFa(s) else s

        val photo = r.photoPath.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() }

        // ---- Row 1, side cell: photo
        val photoXml = if (photo != null) {
            val cx = SIDE_W * 635L
            val cy = cx * 5 / 4
            "<w:p><w:pPr><w:bidi/><w:spacing w:before=\"0\" w:after=\"0\"/></w:pPr><w:r><w:drawing>" +
                "<wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"$cx\" cy=\"$cy\"/>" +
                "<wp:docPr id=\"1\" name=\"photo\"/><a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"0\" name=\"photo.jpg\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                "<pic:blipFill><a:blip r:embed=\"rIdPhoto\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm>" +
                "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>" +
                "</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"
        } else para("", exactLine = 600)

        // ---- Row 1, main cell: bar + name + header info
        val head = StringBuilder()
        head.append(para("", shade = NAVY, exactLine = 1000))
        head.append(para(run(t(r.name), 56, true, NAVY), before = 300, after = 160))
        for (h in r.headerInfo) {
            val line = (if (h.title.isNotBlank()) t(h.title) + ": " else "") + t(h.subtitle)
            head.append(para(run(line, 22, false, "555555"), after = 40))
        }

        // ---- Row 2, side cell: contact + ratings
        val side = StringBuilder()
        if (r.phone.isNotBlank()) {
            side.append(para(run("تلفن", 22, true, "FFFFFF"), before = 240))
            side.append(para(run(t(r.phone), 22, false, "FFFFFF")))
        }
        if (r.address.isNotBlank()) {
            side.append(para(run("آدرس", 22, true, "FFFFFF"), before = 240))
            side.append(para(run(t(r.address), 22, false, "FFFFFF")))
        }
        for (s in r.sections.filter { it.type == SectionType.RATINGS }) {
            side.append(para(run(t(s.title), 30, true, "FFFFFF"), before = 480, after = 160, center = true, keepNext = true))
            for (it in s.items) {
                val n = it.rating.coerceIn(0, 5)
                side.append(para(run(t(it.title), 22, false, "FFFFFF"), before = 120, keepNext = true))
                side.append(
                    para(
                        run("★".repeat(n), 28, false, "FFFFFF") + run("★".repeat(5 - n), 28, false, "8C9AF0"),
                        after = 40
                    )
                )
            }
        }

        // ---- Row 2, main cell: sections
        val main = StringBuilder()
        for (s in r.sections.filter { it.type != SectionType.RATINGS }) {
            main.append(para(run(t(s.title), 30, true, "FFFFFF"), shade = SECTION, before = 280, after = 140, keepNext = true))
            for (it in s.items) {
                if (s.type == SectionType.INFO) {
                    val label = if (it.title.isNotBlank()) run(t(it.title) + ": ", 24, true) else ""
                    main.append(para(label + run(t(it.subtitle), 24), after = 60))
                } else {
                    main.append(para(run("◄ ", 20, false, SECTION) + run(t(it.title), 26, true, NAVY), before = 80, keepNext = true))
                    if (it.subtitle.isNotBlank()) main.append(para(run(t(it.subtitle), 23), keepNext = true))
                    if (it.date.isNotBlank()) main.append(para(run(t(it.date), 19, false, "777777"), keepNext = it.desc.isNotBlank()))
                    if (it.desc.isNotBlank()) main.append(para(run(t(it.desc), 23), after = 100))
                    else main.append(para("", after = 60))
                }
            }
        }

        val doc = StringBuilder()
        doc.append(
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
                "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
                "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
                "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>"
        )
        doc.append("<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w=\"11906\" w:type=\"dxa\"/><w:tblLayout w:type=\"fixed\"/></w:tblPr>")
        doc.append("<w:tblGrid><w:gridCol w:w=\"$SIDE_W\"/><w:gridCol w:w=\"$MAIN_W\"/></w:tblGrid>")
        doc.append("<w:tr>")
            .append(cell(SIDE_W, null, 0, photoXml))
            .append(cell(MAIN_W, null, 300, head.toString()))
            .append("</w:tr>")
        doc.append("<w:tr>")
            .append(cell(SIDE_W, BLUE, 220, side.toString()))
            .append(cell(MAIN_W, null, 300, main.toString()))
            .append("</w:tr></w:tbl>")
        doc.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"20\" w:lineRule=\"exact\"/></w:pPr></w:p>")
        doc.append(
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
                "<w:pgMar w:top=\"0\" w:right=\"0\" w:bottom=\"0\" w:left=\"0\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/>" +
                "</w:sectPr></w:body></w:document>"
        )

        val contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"
        val rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"
        val docRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            (if (photo != null)
                "<Relationship Id=\"rIdPhoto\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/photo.jpg\"/>"
            else "") +
            "</Relationships>"

        ZipOutputStream(FileOutputStream(out)).use { z ->
            fun put(name: String, bytes: ByteArray) {
                z.putNextEntry(ZipEntry(name))
                z.write(bytes)
                z.closeEntry()
            }
            put("[Content_Types].xml", contentTypes.toByteArray(Charsets.UTF_8))
            put("_rels/.rels", rootRels.toByteArray(Charsets.UTF_8))
            put("word/document.xml", doc.toString().toByteArray(Charsets.UTF_8))
            put("word/_rels/document.xml.rels", docRels.toByteArray(Charsets.UTF_8))
            if (photo != null) put("word/media/photo.jpg", photo.readBytes())
        }
    }
}
