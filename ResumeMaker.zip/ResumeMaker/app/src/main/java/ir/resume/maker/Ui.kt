package ir.resume.maker

import android.graphics.BitmapFactory
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val Blue = Color(0xFF2B3FC4)
private val Navy = Color(0xFF1B2559)
private val Bg = Color(0xFFF4F5FB)
private val Danger = Color(0xFFC62828)

private val Vazir = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_bold, FontWeight.Bold)
)

private fun vazirTypography(): Typography {
    val b = Typography()
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = Vazir),
        displayMedium = b.displayMedium.copy(fontFamily = Vazir),
        displaySmall = b.displaySmall.copy(fontFamily = Vazir),
        headlineLarge = b.headlineLarge.copy(fontFamily = Vazir),
        headlineMedium = b.headlineMedium.copy(fontFamily = Vazir),
        headlineSmall = b.headlineSmall.copy(fontFamily = Vazir),
        titleLarge = b.titleLarge.copy(fontFamily = Vazir),
        titleMedium = b.titleMedium.copy(fontFamily = Vazir),
        titleSmall = b.titleSmall.copy(fontFamily = Vazir),
        bodyLarge = b.bodyLarge.copy(fontFamily = Vazir),
        bodyMedium = b.bodyMedium.copy(fontFamily = Vazir),
        bodySmall = b.bodySmall.copy(fontFamily = Vazir),
        labelLarge = b.labelLarge.copy(fontFamily = Vazir),
        labelMedium = b.labelMedium.copy(fontFamily = Vazir),
        labelSmall = b.labelSmall.copy(fontFamily = Vazir)
    )
}

sealed interface Screen {
    data object Home : Screen
    data object Personal : Screen
    data object Preview : Screen
    data class Edit(val id: String) : Screen
}

@Composable
fun ResumeApp(onPdf: (Resume) -> Unit, onDocx: (Resume) -> Unit) {
    val ctx = LocalContext.current
    var resume by remember { mutableStateOf(Storage.load(ctx)) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    val update: (Resume) -> Unit = {
        resume = it
        Storage.save(ctx, it)
    }

    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Navy), typography = vazirTypography()) {
            Surface(Modifier.fillMaxSize().systemBarsPadding().imePadding(), color = Bg) {
                when (val s = screen) {
                    Screen.Home -> HomeScreen(
                        resume = resume,
                        onUpdate = update,
                        onPersonal = { screen = Screen.Personal },
                        onEdit = { screen = Screen.Edit(it) },
                        onPreview = { screen = Screen.Preview },
                        onPdf = { onPdf(resume) },
                        onDocx = { onDocx(resume) }
                    )

                    Screen.Personal -> PersonalScreen(resume, update) { screen = Screen.Home }
                    Screen.Preview -> PreviewScreen(
                        resume = resume,
                        onBack = { screen = Screen.Home },
                        onPdf = { onPdf(resume) },
                        onDocx = { onDocx(resume) }
                    )

                    is Screen.Edit -> {
                        val sec = resume.sections.firstOrNull { it.id == s.id }
                        if (sec == null) {
                            LaunchedEffect(s) { screen = Screen.Home }
                        } else {
                            SectionScreen(
                                section = sec,
                                onChange = { n ->
                                    update(resume.copy(sections = resume.sections.map { if (it.id == n.id) n else it }))
                                },
                                onBack = { screen = Screen.Home }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(Navy).padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = onBack) { Text("بازگشت", color = Color.White) }
        Text(
            title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
            modifier = Modifier.weight(1f)
        )
        actions()
    }
}

@Composable
fun Field(label: String, value: String, lines: Int = 1, kb: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        minLines = lines,
        keyboardOptions = KeyboardOptions(keyboardType = kb)
    )
}

// ------------------------------------------------------------------ Home

@Composable
fun HomeScreen(
    resume: Resume,
    onUpdate: (Resume) -> Unit,
    onPersonal: () -> Unit,
    onEdit: (String) -> Unit,
    onPreview: () -> Unit,
    onPdf: () -> Unit,
    onDocx: () -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Section?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("رزومه‌ساز", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text("بخش‌ها را ویرایش کنید، اضافه کنید یا ترتیبشان را عوض کنید.", color = Color.Gray, fontSize = 14.sp)
        }
        item {
            Card(
                Modifier.fillMaxWidth().clickable { onPersonal() },
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("اطلاعات شخصی", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Navy)
                    Text("نام، عکس، تلفن، آدرس و مشخصات کنار نام", color = Color.Gray, fontSize = 13.sp)
                }
            }
        }
        itemsIndexed(resume.sections, key = { _, s -> s.id }) { index, s ->
            Card(
                Modifier.fillMaxWidth().clickable { onEdit(s.id) },
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(Modifier.padding(start = 4.dp, top = 8.dp, bottom = 8.dp, end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.title.ifBlank { "(بدون عنوان)" }, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Navy)
                        Text("${s.items.size} مورد", color = Color.Gray, fontSize = 13.sp)
                    }
                    TextButton(onClick = { onUpdate(resume.copy(sections = resume.sections.moved(index, -1))) }) { Text("▲") }
                    TextButton(onClick = { onUpdate(resume.copy(sections = resume.sections.moved(index, 1))) }) { Text("▼") }
                    TextButton(onClick = { toDelete = s }) { Text("حذف", color = Danger) }
                }
            }
        }
        item {
            OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ افزودن بخش جدید") }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("نمایش اعداد به‌صورت فارسی", modifier = Modifier.weight(1f))
                Switch(checked = resume.persianDigits, onCheckedChange = { onUpdate(resume.copy(persianDigits = it)) })
            }
        }
        item {
            Button(onClick = onPreview, modifier = Modifier.fillMaxWidth()) { Text("پیش‌نمایش رزومه") }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onPdf, modifier = Modifier.weight(1f)) { Text("خروجی PDF") }
                Button(onClick = onDocx, modifier = Modifier.weight(1f)) { Text("خروجی Word") }
            }
        }
    }

    if (showAdd) {
        AddSectionDialog(
            onDismiss = { showAdd = false },
            onAdd = { title, type ->
                onUpdate(resume.copy(sections = resume.sections + Section(type = type, title = title)))
                showAdd = false
            }
        )
    }
    toDelete?.let { d ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف بخش") },
            text = { Text("بخش «${d.title}» و همه موارد آن حذف شود؟") },
            confirmButton = {
                TextButton(onClick = {
                    onUpdate(resume.copy(sections = resume.sections.filter { it.id != d.id }))
                    toDelete = null
                }) { Text("حذف", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("انصراف") } }
        )
    }
}

@Composable
fun AddSectionDialog(onDismiss: () -> Unit, onAdd: (String, SectionType) -> Unit) {
    var title by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(SectionType.ENTRIES) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بخش جدید") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Field("عنوان بخش (مثلاً پروژه‌ها)", title) { title = it }
                for (t in SectionType.values()) {
                    Row(
                        Modifier.fillMaxWidth().clickable { type = t },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = type == t, onClick = { type = t })
                        Text(t.label, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (title.isNotBlank()) onAdd(title.trim(), type) }) { Text("افزودن") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

// ------------------------------------------------------------------ Personal

@Composable
fun PersonalScreen(resume: Resume, onUpdate: (Resume) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val path = Storage.savePhoto(ctx, uri, resume.photoPath)
            if (path != null) onUpdate(resume.copy(photoPath = path))
        }
    }
    val bmp = remember(resume.photoPath) {
        if (resume.photoPath.isNotEmpty()) BitmapFactory.decodeFile(resume.photoPath)?.asImageBitmap() else null
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("اطلاعات شخصی", onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (bmp != null) {
                    Image(
                        bitmap = bmp, contentDescription = null,
                        modifier = Modifier.size(width = 80.dp, height = 100.dp),
                        contentScale = ContentScale.Crop
                    )
                }
                Column {
                    Button(onClick = { picker.launch("image/*") }) { Text(if (bmp == null) "انتخاب عکس" else "تغییر عکس") }
                    if (bmp != null) {
                        TextButton(onClick = { onUpdate(resume.copy(photoPath = "")) }) { Text("حذف عکس", color = Danger) }
                    }
                }
            }
            Field("نام و نام خانوادگی", resume.name) { onUpdate(resume.copy(name = it)) }
            Field("شماره تماس", resume.phone, kb = KeyboardType.Phone) { onUpdate(resume.copy(phone = it)) }
            Field("آدرس", resume.address, lines = 2) { onUpdate(resume.copy(address = it)) }

            Text("مشخصات زیر نام", fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.padding(top = 8.dp))
            resume.headerInfo.forEachIndexed { i, item ->
                ItemEditor(
                    type = SectionType.INFO, item = item,
                    onChange = { n -> onUpdate(resume.copy(headerInfo = resume.headerInfo.map { if (it.id == n.id) n else it })) },
                    onUp = { onUpdate(resume.copy(headerInfo = resume.headerInfo.moved(i, -1))) },
                    onDown = { onUpdate(resume.copy(headerInfo = resume.headerInfo.moved(i, 1))) },
                    onDelete = { onUpdate(resume.copy(headerInfo = resume.headerInfo.filter { it.id != item.id })) }
                )
            }
            OutlinedButton(
                onClick = { onUpdate(resume.copy(headerInfo = resume.headerInfo + Item())) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("+ افزودن مشخصه") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ------------------------------------------------------------------ Section editor

@Composable
fun SectionScreen(section: Section, onChange: (Section) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar(section.title.ifBlank { "ویرایش بخش" }, onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Field("عنوان بخش", section.title) { onChange(section.copy(title = it)) }
            Text("نوع: ${section.type.label}", color = Color.Gray, fontSize = 13.sp)
            section.items.forEachIndexed { i, item ->
                ItemEditor(
                    type = section.type, item = item,
                    onChange = { n -> onChange(section.copy(items = section.items.map { if (it.id == n.id) n else it })) },
                    onUp = { onChange(section.copy(items = section.items.moved(i, -1))) },
                    onDown = { onChange(section.copy(items = section.items.moved(i, 1))) },
                    onDelete = { onChange(section.copy(items = section.items.filter { it.id != item.id })) }
                )
            }
            Button(
                onClick = { onChange(section.copy(items = section.items + Item(rating = 5))) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("+ افزودن مورد") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun ItemEditor(
    type: SectionType,
    item: Item,
    onChange: (Item) -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onDelete: () -> Unit
) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (type) {
                SectionType.INFO -> {
                    Field("عنوان (مثلاً کد ملی)", item.title) { onChange(item.copy(title = it)) }
                    Field("مقدار", item.subtitle) { onChange(item.copy(subtitle = it)) }
                }

                SectionType.ENTRIES -> {
                    Field("سمت / مدرک", item.title) { onChange(item.copy(title = it)) }
                    Field("محل (شرکت / دانشگاه)", item.subtitle) { onChange(item.copy(subtitle = it)) }
                    Field("تاریخ (مثلاً 1395/01/01 - 1399/01/01)", item.date) { onChange(item.copy(date = it)) }
                    Field("توضیحات", item.desc, lines = 3) { onChange(item.copy(desc = it)) }
                }

                SectionType.RATINGS -> {
                    Field("عنوان (مثلاً مهارت یا زبان)", item.title) { onChange(item.copy(title = it)) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("امتیاز: ")
                        for (i in 1..5) {
                            Text(
                                if (i <= item.rating) "★" else "☆",
                                fontSize = 30.sp, color = Blue,
                                modifier = Modifier.clickable { onChange(item.copy(rating = i)) }.padding(4.dp)
                            )
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onUp) { Text("▲ بالا") }
                TextButton(onClick = onDown) { Text("▼ پایین") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDelete) { Text("حذف", color = Danger) }
            }
        }
    }
}

// ------------------------------------------------------------------ Preview

@Composable
fun PreviewScreen(resume: Resume, onBack: () -> Unit, onPdf: () -> Unit, onDocx: () -> Unit) {
    val html = remember(resume) { HtmlExporter.build(resume) }
    Column(Modifier.fillMaxSize()) {
        TopBar("پیش‌نمایش", onBack) {
            TextButton(onClick = onPdf) { Text("PDF", color = Color.White) }
            TextButton(onClick = onDocx) { Text("Word", color = Color.White) }
        }
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                WebView(c).apply {
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
                }
            },
            update = { w ->
                if (w.tag != html) {
                    w.tag = html
                    w.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
                }
            }
        )
    }
}
