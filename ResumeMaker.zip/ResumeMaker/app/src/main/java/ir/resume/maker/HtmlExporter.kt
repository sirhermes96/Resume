package ir.resume.maker

import android.util.Base64
import java.io.File

object HtmlExporter {

    private const val PHONE_ICON =
        "<svg viewBox=\"0 0 24 24\" width=\"22\" height=\"22\"><path fill=\"#fff\" d=\"M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.6 21 3 13.4 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z\"/></svg>"
    private const val PIN_ICON =
        "<svg viewBox=\"0 0 24 24\" width=\"22\" height=\"22\"><path fill=\"#fff\" d=\"M12 2C8.1 2 5 5.1 5 9c0 5.2 7 13 7 13s7-7.8 7-13c0-3.9-3.1-7-7-7zm0 9.5c-1.4 0-2.5-1.1-2.5-2.5S10.6 6.5 12 6.5s2.5 1.1 2.5 2.5S13.4 11.5 12 11.5z\"/></svg>"

    private val CSS = """
@font-face{font-family:'Vazirmatn';src:url('fonts/Vazirmatn-Regular.ttf');font-weight:400}
@font-face{font-family:'Vazirmatn';src:url('fonts/Vazirmatn-Bold.ttf');font-weight:700}
@page{size:A4;margin:0}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{direction:rtl;font-family:'Vazirmatn','Vazir',Tahoma,sans-serif;color:#1a1a1a;width:100%;
-webkit-print-color-adjust:exact;print-color-adjust:exact;
background:linear-gradient(to left,#3346d3 0,#3346d3 33%,#fff 33%,#fff 100%)}
.wrap{display:flex;direction:rtl;width:100%;align-items:stretch}
.side{width:33%;flex:none;color:#fff}
.main{width:67%;flex:none;padding-bottom:24px}
.photo{background:#fff;min-height:40px;line-height:0}
.photo img{width:100%;aspect-ratio:4/5;object-fit:cover;display:block}
.crow{display:flex;align-items:center;margin:14px 0 0 0;break-inside:avoid}
.ico{width:40px;min-height:44px;background:#1b2559;flex:none;display:flex;align-items:center;justify-content:center;border-radius:0 0 0 0}
.ctext{padding:0 10px;font-size:14px;line-height:1.7;direction:ltr;text-align:right;unicode-bidi:plaintext}
.sh{font-size:21px;font-weight:700;text-align:center;margin:28px 0 12px;break-after:avoid}
.rt{display:flex;align-items:center;justify-content:space-between;margin:10px 14px;gap:8px;break-inside:avoid}
.rt .n{font-size:14px;line-height:1.6;flex:1}
.stars{background:rgba(27,37,89,.35);padding:3px 8px;font-size:15px;letter-spacing:1px;white-space:nowrap;direction:rtl}
.stars .on{color:#fff}.stars .off{color:rgba(255,255,255,.35)}
.bar{direction:ltr;display:flex;height:64px}
.bar .navy{flex:1;background:#1b2559}
.bar svg{width:110px;height:64px;display:block}
h1{margin:30px 22px 14px;font-size:38px;color:#1b2559;font-weight:700}
.hi{margin:0 22px;font-size:15px;color:#555;line-height:1.9}
.st{position:relative;background:#2b3fc4;color:#fff;font-weight:700;font-size:21px;padding:14px 22px;margin:22px 0 12px 14px;break-after:avoid}
.st::before{content:"";position:absolute;left:-14px;top:0;bottom:0;width:84px;background:#1b2559;clip-path:polygon(0 0,45% 0,100% 100%,55% 100%)}
.info{margin:4px 22px;font-size:17px;line-height:1.8}
.info b{font-weight:700}
.ent{margin:0 22px 14px;break-inside:avoid}
.ent .t{font-weight:700;color:#1b2559;font-size:17px}
.ent .t::before{content:"";display:inline-block;border-top:5px solid transparent;border-bottom:5px solid transparent;border-right:8px solid #2b3fc4;margin-left:8px}
.ent .sub{font-size:15px;margin:3px 18px 0 0}
.ent .date{font-size:13px;color:#777;margin:2px 18px 0 0}
.ent .desc{font-size:15px;margin:3px 18px 0 0;line-height:1.7}
"""

    private fun esc(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("\n", "<br>")

    private fun photoUri(path: String): String? {
        if (path.isBlank()) return null
        val f = File(path)
        if (!f.exists()) return null
        return "data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
    }

    fun build(r: Resume): String {
        fun t(s: String): String = esc(if (r.persianDigits) toFa(s) else s)

        val sb = StringBuilder()
        sb.append("<!DOCTYPE html><html lang=\"fa\" dir=\"rtl\"><head><meta charset=\"utf-8\">")
        sb.append("<meta name=\"viewport\" content=\"width=794\"><style>").append(CSS).append("</style></head><body><div class=\"wrap\">")

        // ---- Sidebar (right in RTL)
        sb.append("<div class=\"side\"><div class=\"photo\">")
        photoUri(r.photoPath)?.let { sb.append("<img src=\"").append(it).append("\">") }
        sb.append("</div>")
        if (r.phone.isNotBlank()) {
            sb.append("<div class=\"crow\"><div class=\"ico\">").append(PHONE_ICON)
                .append("</div><div class=\"ctext\">").append(t(r.phone)).append("</div></div>")
        }
        if (r.address.isNotBlank()) {
            sb.append("<div class=\"crow\"><div class=\"ico\">").append(PIN_ICON)
                .append("</div><div class=\"ctext\">").append(t(r.address)).append("</div></div>")
        }
        for (s in r.sections.filter { it.type == SectionType.RATINGS }) {
            sb.append("<div class=\"sh\">").append(t(s.title)).append("</div>")
            for (it in s.items) {
                val n = it.rating.coerceIn(0, 5)
                sb.append("<div class=\"rt\"><span class=\"n\">").append(t(it.title))
                    .append("</span><span class=\"stars\"><span class=\"on\">").append("★".repeat(n))
                    .append("</span><span class=\"off\">").append("★".repeat(5 - n))
                    .append("</span></span></div>")
            }
        }
        sb.append("</div>")

        // ---- Main column
        sb.append("<div class=\"main\"><div class=\"bar\"><div class=\"navy\"></div>")
        sb.append("<svg viewBox=\"0 0 110 64\" preserveAspectRatio=\"none\">")
        sb.append("<polygon points=\"0,0 40,0 10,64 0,64\" fill=\"#1b2559\"/>")
        sb.append("<polygon points=\"18,64 48,0 70,0 40,64\" fill=\"#2b3fc4\"/>")
        sb.append("<polygon points=\"50,64 80,0 102,0 72,64\" fill=\"#5a6ee0\"/>")
        sb.append("</svg></div>")
        sb.append("<h1>").append(t(r.name)).append("</h1>")
        for (h in r.headerInfo) {
            sb.append("<div class=\"hi\">")
            if (h.title.isNotBlank()) sb.append(t(h.title)).append(": ")
            sb.append(t(h.subtitle)).append("</div>")
        }
        for (s in r.sections.filter { it.type != SectionType.RATINGS }) {
            sb.append("<div class=\"st\">").append(t(s.title)).append("</div>")
            for (it in s.items) {
                if (s.type == SectionType.INFO) {
                    sb.append("<div class=\"info\">")
                    if (it.title.isNotBlank()) sb.append("<b>").append(t(it.title)).append(":</b> ")
                    sb.append(t(it.subtitle)).append("</div>")
                } else {
                    sb.append("<div class=\"ent\"><div class=\"t\">").append(t(it.title)).append("</div>")
                    if (it.subtitle.isNotBlank()) sb.append("<div class=\"sub\">").append(t(it.subtitle)).append("</div>")
                    if (it.date.isNotBlank()) sb.append("<div class=\"date\">").append(t(it.date)).append("</div>")
                    if (it.desc.isNotBlank()) sb.append("<div class=\"desc\">").append(t(it.desc)).append("</div>")
                    sb.append("</div>")
                }
            }
        }
        sb.append("</div></div></body></html>")
        return sb.toString()
    }
}
