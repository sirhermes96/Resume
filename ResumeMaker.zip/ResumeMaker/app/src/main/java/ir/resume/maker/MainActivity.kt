package ir.resume.maker

import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File

private const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

class MainActivity : ComponentActivity() {

    private var printView: WebView? = null
    private var pendingDocx: File? = null

    private val saveDocx = registerForActivityResult(ActivityResultContracts.CreateDocument(DOCX_MIME)) { uri ->
        val f = pendingDocx
        if (uri != null && f != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                Toast.makeText(this, "فایل Word ذخیره شد", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "ذخیره فایل ناموفق بود", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ResumeApp(onPdf = ::exportPdf, onDocx = ::exportDocx) }
    }

    private fun fileName(r: Resume): String {
        val base = "رزومه " + r.name.trim()
        return base.replace(Regex("[\\\\/:*?\"<>|]"), "").trim().ifBlank { "resume" }
    }

    /** Renders the HTML design and opens Android's print dialog, where "Save as PDF" is available. */
    private fun exportPdf(r: Resume) {
        val html = HtmlExporter.build(r)
        val job = fileName(r)
        val wv = WebView(this)
        var printed = false
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                if (printed) return
                printed = true
                val pm = getSystemService(PRINT_SERVICE) as PrintManager
                val attrs = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()
                pm.print(job, view.createPrintDocumentAdapter(job), attrs)
            }
        }
        printView = wv
        wv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
    }

    private fun exportDocx(r: Resume) {
        Thread {
            try {
                val f = File(cacheDir, "resume.docx")
                DocxExporter.export(r, f)
                pendingDocx = f
                runOnUiThread { saveDocx.launch(fileName(r) + ".docx") }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "خطا در ساخت فایل Word: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
